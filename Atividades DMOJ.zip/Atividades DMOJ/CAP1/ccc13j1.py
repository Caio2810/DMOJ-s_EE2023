nova = int(input())
meio = int(input())
dif = meio - nova
velha = meio + dif

print(velha)