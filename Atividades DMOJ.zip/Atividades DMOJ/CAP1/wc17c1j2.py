celsius = int(input())
fahrenheit = (9/5) * celsius + 32

print(fahrenheit)
