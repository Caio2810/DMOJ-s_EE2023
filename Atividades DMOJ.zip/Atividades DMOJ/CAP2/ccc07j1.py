peso_tig = []

p1 = int(input())
if 0 <= p1 <= 100:
    peso_tig.append(p1)
else:
    print("erro")


p2 = int(input())
if 0 <= p1 <= 100:
    peso_tig.append(p2)
else:
    print("erro")

p3 = int(input())
if 0 <= p1 <= 100:
    peso_tig.append(p3)
else:
    print("erro")

peso_tig.sort()
print(peso_tig[1])


    
                   