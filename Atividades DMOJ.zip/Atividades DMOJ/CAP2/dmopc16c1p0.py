w = int(input())
c = int(input())

if w==1 and c<=50:
    M = ("fairly")
elif w==3 and c>=95:
    M = ("absolutely")
else:
    M = ("very")
print('C.C. is',M,'satisfied with her pizza.')


